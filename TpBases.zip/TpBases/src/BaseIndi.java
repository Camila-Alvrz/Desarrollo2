public class BaseIndi  extends Base{
    private int NumeroAmbulacias;
    private float TiempoMedioDeAsistencia;

    public int getNumeroAmbulacias() {
        return NumeroAmbulacias;
    }

    public void setNumeroAmbulacias(int numeroAmbulacias) {
        NumeroAmbulacias = numeroAmbulacias;
    }

    public float getTiempoMedioDeAsistencia() {
        return TiempoMedioDeAsistencia;
    }

    public void setTiempoMedioDeAsistencia(float tiempoMedioDeAsistencia) {
        TiempoMedioDeAsistencia = tiempoMedioDeAsistencia;
    }
}
